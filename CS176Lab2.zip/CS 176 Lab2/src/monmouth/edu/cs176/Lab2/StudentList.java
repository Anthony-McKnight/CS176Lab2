package monmouth.edu.cs176.Lab2;

public class StudentList {
	 Student [] cs176Students ;
	 private int count =0;
	 /**
	 * Constructor for StudentList Class
	 */
	 StudentList (int totalStudents) {
	 cs176Students = new Student[totalStudents];
	 }
	 /**
	 * @param s - new student object
	 */
	 public void addStudent (Student s) {
	 cs176Students[count]= s;
	 count++;

	 }
	 /**
	 * List the Student using for-each loop
	 */
	 public void listStudents() {
	 for (Student s: cs176Students) {
	 System.out.println(s.toString());
	 }
	 }
	 public Integer studentCount(String major) {
	  Integer count=0;
	  for(Student s : cs176Students) {
	   if( s.getMajor() == major) {
	    
	   }
	  }
	 return count;
	 
	 
	 }
}